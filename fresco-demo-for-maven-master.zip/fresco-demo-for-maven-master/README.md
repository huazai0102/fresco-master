Fresco 的 简单的 Itellij IDEA 中的 Maven 工程示例。

APK: 
